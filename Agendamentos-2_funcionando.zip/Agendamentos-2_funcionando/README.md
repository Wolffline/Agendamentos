# CRUD-MVC-PHP
Crud em MVC e PHP
### Objetivo: 

>Desenvolver um sistema CRUD simples em PHP 5 ou 7 (sem frameworks) e MySQL para a administração de serviços agendados.
